#include <iostream>
#include <vector>
using namespace std;

void  insertionSort(std::vector<int> &vetor) {

    for (int i = 1; i < vetor.size(); i++) {
		int escolhido = vetor[i];
		int j = i - 1;
		
		while ((j >= 0) && (vetor[j] > escolhido)) {
			vetor[j + 1] = vetor[j];
			j--;
		}
		
		vetor[j + 1] = escolhido;
	}
}

int main() {
    vector<int> lista = {5, 3, 6, 1};
    cout << "Lista antes da ordenacao: ";
    for (int i : lista) {
        cout << i << " ";
    }
    cout << endl;

    insertionSort(lista);

    cout << "Lista apos a ordenacao: ";
    for (int i : lista) {
        cout << i << " ";
    }
    cout << endl;

    return 0;
}
