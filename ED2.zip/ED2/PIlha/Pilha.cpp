#include "Pilha.h"

int main(){
    Pilha pilha;
    pilha.inserirElemento(1);
    pilha.inserirElemento(2);
    pilha.inserirElemento(3);

    pilha.imprimirPilha();

    cout << "\nTopo da pilha: " << pilha.topoDaPilha() << endl;

    pilha.deletarElemento();
    pilha.imprimirPilha();

    pilha.inserirElemento(1);

    pilha.imprimirPilha();
    return 0;
}
